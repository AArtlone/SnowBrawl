$(document).ready(function(){

    
});



























































/*var config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

var game = new Phaser.Game(config);




function preload()
{

    this.load.spritesheet('character', 
        'data/character.png',
       { frameWidth: 107, frameHeight: 131 }
    );
}

function create() 
{

this.add.image(400, 800, 'character');
}

function update() {

}




/*var character = new Image();
character.src = 'data/sprites.png';

function sprite (options) {
				
    var that = {};
					
    that.context = options.context;
    that.width = options.width;
    that.height = options.height;
    that.image = options.image;

    return that;

    that.render = function () {

        // Draw the animation
        that.context.drawImage(
           that.image,
           0,
           0,
           that.width,
           that.height,
           0,
           0,
           that.width,
           that.height);
    };
}

char.render();

var canvas = document.getElementById("characterAnimation");
canvas.width = 100;
canvas.height = 100;

var char = sprite({
    context: canvas.getContext("2d"),
    width: 100,
    height: 100,
    image: character
});
*/